"""Evaluator module for Phase 6.

Evaluates objective verification signals (test pass/fail, lint pass/fail,
repeated failure counts) to produce a structured EvaluatorResult dict.
"""

from typing import Optional, List, TypedDict, Dict, Any


class EvaluatorResult(TypedDict):
    is_correct: bool
    score: float
    issues: List[str]
    critical_gaps: List[str]
    feedback: str


def evaluate_iteration(
    test_passed: bool,
    test_output_tail: str,
    lint_passed: Optional[bool] = None,
    lint_output_tail: Optional[str] = None,
    same_failure_count: int = 0,
) -> EvaluatorResult:
    """Evaluate raw verification signals into a structured evaluator result.

    Policy Decisions:
    1. Tests MUST pass for ``is_correct`` to be True. If tests fail, score is 0.0,
       issues contains 'tests_failed', and critical_gaps contains 'tests_must_pass'.
    2. Repeated failures (same_failure_count >= 2) are weighted as a critical gap
       ('repeated_same_failure') and recorded in issues ('repeated_failure').
    3. Lint failures are treated as informational code-quality issues. If tests pass
       but lint fails, ``is_correct`` remains True, score is reduced to 0.9, and
       issues contains 'lint_failed'. Lint alone never creates a critical gap or blocks correctness.
    """
    issues: List[str] = []
    critical_gaps: List[str] = []

    if not test_passed:
        issues.append("tests_failed")
        critical_gaps.append("tests_must_pass")
        if same_failure_count >= 2:
            issues.append("repeated_failure")
            critical_gaps.append("repeated_same_failure")

    if lint_passed is False:
        issues.append("lint_failed")

    # Score calculation & feedback composition
    if test_passed:
        is_correct = True
        score = 1.0
        if lint_passed is False:
            feedback = "Tests passed but lint reported issues."
        else:
            feedback = "All verification checks passed."
    else:
        is_correct = False
        score = 0.0
        tail_preview = (test_output_tail or "")[:200]
        if same_failure_count >= 2:
            feedback = f"Repeated failure ({same_failure_count} times). Output tail: {tail_preview}"
        else:
            feedback = f"Tests failed. Output tail: {tail_preview}"


    return {
        "is_correct": is_correct,
        "score": score,
        "issues": issues,
        "critical_gaps": critical_gaps,
        "feedback": feedback,
    }
