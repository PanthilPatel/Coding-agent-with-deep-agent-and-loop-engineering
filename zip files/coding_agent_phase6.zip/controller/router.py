"""Router module for Phase 6.

Weighs evaluator output against run safety limits (iterations, time, repeated failure thresholds)
to determine whether to continue the execution loop or terminate.
"""

from typing import Optional, TypedDict, Dict, Any
from controller.state import TerminationReason


class RouterDecision(TypedDict):
    continue_loop: bool  # note: 'continue' is a Python keyword, so key in dict is 'continue'
    termination_reason: Optional[str]


def decide_next_step(
    evaluator_result: Dict[str, Any],
    current_iteration: int,
    max_iterations: int,
    elapsed_seconds: float,
    max_seconds: float,
    same_failure_count: int = 0,
    max_same_failures: Optional[int] = None,
) -> Dict[str, Any]:
    """Decide whether to continue the loop or stop, and set the appropriate termination reason.

    Returns a dict:
    {
        "continue": bool,
        "termination_reason": str | None
    }
    """
    is_correct = evaluator_result.get("is_correct", False)

    # 1. Success condition (tests passed)
    if is_correct:
        return {
            "continue": False,
            "termination_reason": TerminationReason.SUCCESS,
        }

    # 2. Timeout check
    if elapsed_seconds > max_seconds:
        return {
            "continue": False,
            "termination_reason": TerminationReason.TIMEOUT,
        }

    # 3. Unrecoverable verification failure check (if max_same_failures threshold configured)
    if max_same_failures is not None and same_failure_count >= max_same_failures:
        return {
            "continue": False,
            "termination_reason": TerminationReason.VERIFICATION_FAILED,
        }

    # 4. Max iterations safety limit check
    if current_iteration >= max_iterations:
        return {
            "continue": False,
            "termination_reason": TerminationReason.MAX_ITERATIONS_SAFETY_LIMIT,
        }

    # 5. Otherwise continue loop
    return {
        "continue": True,
        "termination_reason": None,
    }
