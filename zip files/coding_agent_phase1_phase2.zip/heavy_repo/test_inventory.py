import pytest
from inventory import Inventory


def test_independent_instances_dont_share_state():
    a = Inventory()
    b = Inventory()
    a.add_stock("sku1", 10)
    assert b.items == {}


def test_remove_stock_raises_when_insufficient():
    inv = Inventory({"sku1": 5})
    with pytest.raises(ValueError):
        inv.remove_stock("sku1", 6)


def test_remove_stock_exact_amount_ok():
    inv = Inventory({"sku1": 5})
    inv.remove_stock("sku1", 5)
    assert inv.items["sku1"] == 0


def test_is_low_stock_at_threshold_is_low():
    inv = Inventory({"sku1": 5})
    assert inv.is_low_stock("sku1", threshold=5) is True


def test_restock_needed_includes_zero_stock():
    inv = Inventory({"sku1": 0, "sku2": 20})
    assert "sku1" in inv.restock_needed(threshold=5)
    assert "sku2" not in inv.restock_needed(threshold=5)
