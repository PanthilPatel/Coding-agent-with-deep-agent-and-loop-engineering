def apply_discount(price, percent_off):
    if not 0 <= percent_off <= 100:
        raise ValueError("percent_off must be between 0 and 100")
    # BUG 5: treats percent_off as a fraction instead of a percentage,
    # so apply_discount(100, 10) returns 90.0 * ... wrong scale entirely.
    return price - (price * (percent_off / 100))


def bulk_price(unit_price, quantity, bulk_threshold=10, bulk_discount_percent=15):
    total = unit_price * quantity
    if quantity >= bulk_threshold:
        total = apply_discount(total, bulk_discount_percent)
    return round(total, 2)


def tiered_shipping_cost(order_total):
    # BUG 6: tiers use the wrong boundary operators, so an order of
    # exactly 50 or exactly 100 lands in the wrong bracket.
    if order_total < 50:
        return 7.99
    elif order_total < 100:
        return 4.99
    else:
        return 0.0
