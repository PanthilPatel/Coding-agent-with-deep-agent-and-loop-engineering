class Inventory:
    """Simple stock-keeping unit tracker."""

    def __init__(self, items=None):
        self.items = items.copy() if items else {}

    def add_stock(self, sku, quantity):
        if quantity < 0:
            raise ValueError("quantity must be non-negative")
        self.items[sku] = self.items.get(sku, 0) + quantity

    def remove_stock(self, sku, quantity):
        current = self.items.get(sku, 0)
        if quantity > current:
            raise ValueError(f"not enough stock for {sku}")
        self.items[sku] = current - quantity

    def is_low_stock(self, sku, threshold=5):
        # BUG 3: wrong comparison operator — should flag when stock is at
        # or below threshold, not strictly below it.
        return self.items.get(sku, 0) <= threshold

    def restock_needed(self, threshold=5):
        # BUG 4: uses is_low_stock so it inherits BUG 3, but also skips
        # skus with exactly 0 stock because of a truthiness check.
        return [sku for sku, qty in self.items.items() if self.is_low_stock(sku, threshold)]
