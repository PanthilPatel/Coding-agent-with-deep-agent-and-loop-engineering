from pricing import apply_discount, bulk_price, tiered_shipping_cost


def test_apply_discount_ten_percent():
    assert apply_discount(100, 10) == 90.0


def test_apply_discount_zero_percent_unchanged():
    assert apply_discount(50, 0) == 50


def test_bulk_price_applies_discount_at_threshold():
    # unit price 10, qty 10 -> 100 total, 15% off -> 85.0
    assert bulk_price(10, 10) == 85.0


def test_bulk_price_below_threshold_no_discount():
    assert bulk_price(10, 9) == 90


def test_shipping_free_at_exactly_100():
    assert tiered_shipping_cost(100) == 0.0


def test_shipping_mid_tier_at_exactly_50():
    assert tiered_shipping_cost(50) == 4.99
