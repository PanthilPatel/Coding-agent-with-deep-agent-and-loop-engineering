import subprocess

def run_tests():
    # Running pytest and capturing output to a file to avoid potential buffer issues 
    # and ensure we see the full output.
    try:
        result = subprocess.run(['pytest'], capture_output=True, text=True)
        with open('test_output.txt', 'w') as f:
            f.write(result.stdout)
            f.write("\n--- STDERR ---\n")
            f.write(result.stderr)
        print("Tests completed. Results written to test_output.txt")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    run_tests()
